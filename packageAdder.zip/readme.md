# Add Package
This Plugin helps you to add any npm(css,js) packages in your project (same as codepen features).

## Usage
For using search `Add Package` in command palette(`•••`) and it will open page with some top packages
, you can select any packages and add to your project. You can also search packages.

## Features
- Above 1 million packages are incuded
- Search any packages
- Choose your desired version
- You can add packages to your Project through Api or download files

## Important
* This plugin only works on Acode version `v1.6.1` and above
* This plugin requires internet connection
* for adding packages to your project make sure to first open the html file in editor then run plugin

Contribution are always welcome!

----

**Provide your feedbacks and suggestions and also report bugs(if found) on bellow link**
> https://github.com/bajrangCoder/acode-plugin-packageAdder/issues

**Leave a star 🌟 on github, if this plugin helpfull to you**

----

**Thanks for using Add Package plugin**